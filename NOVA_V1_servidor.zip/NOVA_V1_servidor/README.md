# N.O.V.A. V1 — servidor seguro

Este servidor mantém a chave da API fora do navegador. O arquivo HTML envia apenas a mensagem para `/api/chat`; o servidor chama a API e devolve a resposta.

## 1. Instale o Node.js

Use uma versão LTS recente do Node.js.

## 2. Abra esta pasta no terminal

```bash
cd NOVA_V1_servidor
```

## 3. Instale as dependências

```bash
npm install
```

## 4. Crie o `.env`

Faça uma cópia de `.env.example` com o nome `.env` e coloque sua chave da API **somente nesse arquivo**.

Nunca envie sua chave aqui no chat e nunca coloque a chave dentro do HTML.

## 5. Inicie

```bash
npm start
```

Você deverá ver:

`N.O.V.A. server rodando em http://localhost:3000`

Teste no navegador:

`http://localhost:3000/health`

## 6. Conecte ao HTML

O N.O.V.A. V1 + IA que foi criado anteriormente usa:

`http://localhost:3000/api/chat`

Se o HTML estiver sendo aberto em outro endereço, ajuste `ALLOWED_ORIGINS` no `.env` para o endereço exato dessa página.

### Importante no iPhone

`localhost` no iPhone significa o próprio iPhone. Se o servidor estiver rodando no computador, o iPhone não consegue usar `localhost:3000` para chegar ao computador.

Para colocar a N.O.V.A. no iPhone de verdade, o próximo passo é publicar o servidor em um endereço HTTPS e configurar `ALLOWED_ORIGINS` para o endereço da página. A chave continua somente no servidor.

## Segurança

- A chave não fica no navegador.
- O servidor limita o tamanho da mensagem.
- CORS aceita somente origens configuradas.
- Respostas não são armazenadas pelo servidor deste exemplo.
- Não coloque `.env` no Git.

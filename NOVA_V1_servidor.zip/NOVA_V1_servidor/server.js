import "dotenv/config";
import http from "node:http";
import OpenAI from "openai";

const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || "0.0.0.0";

if (!process.env.OPENAI_API_KEY) {
  console.error("ERRO: defina OPENAI_API_KEY no arquivo .env.");
  process.exit(1);
}

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

const allowedOrigins = new Set(
  (process.env.ALLOWED_ORIGINS || "http://localhost:3000")
    .split(",")
    .map((x) => x.trim())
    .filter(Boolean)
);

function corsHeaders(origin) {
  const allowed = origin && allowedOrigins.has(origin) ? origin : "";
  return {
    "Access-Control-Allow-Origin": allowed,
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
    "Vary": "Origin",
  };
}

function sendJson(res, status, data, origin) {
  const body = JSON.stringify(data);
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    ...corsHeaders(origin),
  });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = "";
    let size = 0;
    const MAX_BODY = 16 * 1024;

    req.on("data", (chunk) => {
      size += chunk.length;
      if (size > MAX_BODY) {
        reject(new Error("REQUEST_TOO_LARGE"));
        req.destroy();
        return;
      }
      data += chunk;
    });

    req.on("end", () => resolve(data));
    req.on("error", reject);
  });
}

const server = http.createServer(async (req, res) => {
  const origin = req.headers.origin || "";

  if (req.method === "OPTIONS") {
    res.writeHead(204, corsHeaders(origin));
    res.end();
    return;
  }

  if (req.method === "GET" && req.url === "/health") {
    sendJson(res, 200, { ok: true, service: "N.O.V.A. V1" }, origin);
    return;
  }

  if (req.method !== "POST" || req.url !== "/api/chat") {
    sendJson(res, 404, { error: "Rota não encontrada." }, origin);
    return;
  }

  // A API key fica SOMENTE no servidor.
  // O navegador nunca recebe essa chave.
  try {
    const raw = await readBody(req);
    const parsed = JSON.parse(raw || "{}");
    const message = typeof parsed.message === "string"
      ? parsed.message.trim()
      : "";

    if (!message) {
      sendJson(res, 400, { error: "Mensagem vazia." }, origin);
      return;
    }

    if (message.length > 4000) {
      sendJson(res, 413, { error: "Mensagem muito longa." }, origin);
      return;
    }

    const response = await openai.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5.6-luna",
      instructions:
        "Você é N.O.V.A., uma assistente de voz amigável para um projeto escolar. " +
        "Responda em português do Brasil, de forma clara e curta. " +
        "Não invente que consegue controlar dispositivos físicos que ainda não estão conectados.",
      input: message,
      max_output_tokens: 500,
    });

    sendJson(res, 200, {
      reply: response.output_text || "Não consegui gerar uma resposta.",
    }, origin);
  } catch (error) {
    console.error(error);

    if (error.message === "REQUEST_TOO_LARGE") {
      sendJson(res, 413, { error: "Requisição muito grande." }, origin);
      return;
    }

    sendJson(res, 500, {
      error: "Erro ao conversar com a IA.",
    }, origin);
  }
});

server.listen(PORT, HOST, () => {
  console.log(`N.O.V.A. server rodando em http://localhost:${PORT}`);
});
